package com.dudalifestyle.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    // IDs oficiais de TESTE do Google AdMob. Trocar pelos IDs reais somente antes da publicação.
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917";

    // Política de intersticial para não irritar a usuária.
    private static final int MAX_INTERSTITIALS_PER_DAY = 3;
    private static final long INTERSTITIAL_COOLDOWN_MS = 4L * 60L * 1000L;

    private WebView webView;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private SharedPreferences adPrefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        adPrefs = getSharedPreferences("duda_ads_policy", MODE_PRIVATE);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        setContentView(webView);

        MobileAds.initialize(this, status -> runOnUiThread(() -> {
            loadInterstitial();
            loadRewarded();
        }));

        webView.loadUrl("file:///android_asset/index.html");
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private boolean canShowInterstitialNow() {
        String today = todayKey();
        String savedDay = adPrefs.getString("day", "");
        int count = adPrefs.getInt("count", 0);
        long lastAt = adPrefs.getLong("last_at", 0L);

        if (!today.equals(savedDay)) {
            adPrefs.edit().putString("day", today).putInt("count", 0).putLong("last_at", 0L).apply();
            count = 0;
            lastAt = 0L;
        }

        if (count >= MAX_INTERSTITIALS_PER_DAY) return false;
        return lastAt == 0L || (System.currentTimeMillis() - lastAt) >= INTERSTITIAL_COOLDOWN_MS;
    }

    private void recordInterstitialShown() {
        adPrefs.edit()
                .putString("day", todayKey())
                .putInt("count", adPrefs.getInt("count", 0) + 1)
                .putLong("last_at", System.currentTimeMillis())
                .apply();
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, TEST_INTERSTITIAL, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                    }
                });
    }

    private void loadRewarded() {
        RewardedAd.load(this, TEST_REWARDED, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    private void showInterstitial() {
        runOnUiThread(() -> {
            if (!canShowInterstitialNow()) return;
            if (interstitialAd == null) {
                loadInterstitial();
                return;
            }

            InterstitialAd current = interstitialAd;
            interstitialAd = null;
            current.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdShowedFullScreenContent() {
                    recordInterstitialShown();
                }
                @Override public void onAdDismissedFullScreenContent() {
                    loadInterstitial();
                }
                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    loadInterstitial();
                }
            });
            current.show(this);
        });
    }

    private void showRewarded() {
        runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewarded();
                webView.evaluateJavascript("Monetization.showToast('Anúncio ainda carregando. Tente novamente em alguns segundos.');", null);
                return;
            }

            RewardedAd current = rewardedAd;
            rewardedAd = null;
            current.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() {
                    loadRewarded();
                }
                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    loadRewarded();
                }
            });

            current.show(this, rewardItem -> webView.evaluateJavascript(
                    "if(window.__dudaRewardCallback){window.__dudaRewardCallback();}", null));
        });
    }

    public class AdsBridge {
        @JavascriptInterface
        public void showInterstitial(String placement) {
            MainActivity.this.showInterstitial();
        }

        @JavascriptInterface
        public void showRewarded(String placement) {
            MainActivity.this.showRewarded();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
