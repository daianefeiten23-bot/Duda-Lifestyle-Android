DUDA LIFESTYLE — PROJETO ANDROID / ADMOB TESTE

Esta versão usa o HTML final zerado e corrigido.

O que já está configurado:
- applicationId: com.dudalifestyle.app
- minSdk 23
- compileSdk 36
- targetSdk 36
- Java 17
- Google Mobile Ads SDK 25.4.0
- WebView com localStorage/DOM Storage
- anúncio recompensado via ponte AndroidAds.showRewarded(...)
- intersticial via ponte AndroidAds.showInterstitial(...)
- IDs oficiais de TESTE do Google AdMob
- sem banner permanente
- intersticial limitado a no máximo 3 por dia
- intervalo mínimo de 4 minutos entre intersticiais
- anúncios recompensados continuam controlados pelo HTML
- desbloqueio por anúncio só concede conteúdo depois do callback de recompensa

IMPORTANTE:
1. NÃO publicar com os IDs de teste.
2. Criar o app no AdMob e substituir o App ID no AndroidManifest.xml.
3. Substituir TEST_INTERSTITIAL e TEST_REWARDED em MainActivity.java pelos IDs reais.
4. Durante desenvolvimento e testes, continuar usando somente anúncios de teste.
5. Antes da publicação, preparar política de privacidade, Data Safety e app-ads.txt.
6. Abrir o projeto no Android Studio e aguardar a sincronização do Gradle.
7. Testar em aparelho real antes de gerar o AAB.

HTML incorporado:
Duda_Lifestyle_ZERADO_CORRIGIDO_FINAL.html
