package com.dudalifestyle.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Calendar;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    // IDs oficiais de TESTE do Google AdMob. Trocar pelos IDs reais somente antes da publicação.
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917";

    // Política de intersticial para não irritar a usuária.
    private static final int MAX_INTERSTITIALS_PER_DAY = 3;
    private static final long INTERSTITIAL_COOLDOWN_MS = 4L * 60L * 1000L;

    private WebView webView;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private SharedPreferences adPrefs;
    private SharedPreferences reminderPrefs;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        adPrefs = getSharedPreferences("duda_ads_policy", MODE_PRIVATE);
        reminderPrefs = getSharedPreferences("duda_reminders", MODE_PRIVATE);
        createNotificationChannel();

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        webView.addJavascriptInterface(new RemindersBridge(), "AndroidReminders");
        setContentView(webView);

        MobileAds.initialize(this, status -> runOnUiThread(() -> {
            loadInterstitial();
            loadRewarded();
        }));

        webView.loadUrl("file:///android_asset/index.html");
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private boolean canShowInterstitialNow() {
        String today = todayKey();
        String savedDay = adPrefs.getString("day", "");
        int count = adPrefs.getInt("count", 0);
        long lastAt = adPrefs.getLong("last_at", 0L);

        if (!today.equals(savedDay)) {
            adPrefs.edit().putString("day", today).putInt("count", 0).putLong("last_at", 0L).apply();
            count = 0;
            lastAt = 0L;
        }

        if (count >= MAX_INTERSTITIALS_PER_DAY) return false;
        return lastAt == 0L || (System.currentTimeMillis() - lastAt) >= INTERSTITIAL_COOLDOWN_MS;
    }

    private void recordInterstitialShown() {
        adPrefs.edit()
                .putString("day", todayKey())
                .putInt("count", adPrefs.getInt("count", 0) + 1)
                .putLong("last_at", System.currentTimeMillis())
                .apply();
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, TEST_INTERSTITIAL, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                    }
                });
    }

    private void loadRewarded() {
        RewardedAd.load(this, TEST_REWARDED, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    private void showInterstitial() {
        runOnUiThread(() -> {
            if (!canShowInterstitialNow()) return;
            if (interstitialAd == null) {
                loadInterstitial();
                return;
            }

            InterstitialAd current = interstitialAd;
            interstitialAd = null;
            current.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdShowedFullScreenContent() {
                    recordInterstitialShown();
                }
                @Override public void onAdDismissedFullScreenContent() {
                    loadInterstitial();
                }
                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    loadInterstitial();
                }
            });
            current.show(this);
        });
    }

    private void showRewarded() {
        runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewarded();
                webView.evaluateJavascript("Monetization.showToast('Anúncio ainda carregando. Tente novamente em alguns segundos.');", null);
                return;
            }

            RewardedAd current = rewardedAd;
            rewardedAd = null;
            current.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() {
                    loadRewarded();
                }
                @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    loadRewarded();
                }
            });

            current.show(this, rewardItem -> webView.evaluateJavascript(
                    "if(window.__dudaRewardCallback){window.__dudaRewardCallback();}", null));
        });
    }


    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "duda_daily", "Lembretes do Duda Lifestyle", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Água, Meu Dia, receitas e Mia");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void scheduleReminder(int id, int hour, int minute, String title, String text) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.putExtra("id", id); intent.putExtra("title", title); intent.putExtra("text", text);
        PendingIntent pi = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    private void enableAllReminders() {
        reminderPrefs.edit().putBoolean("enabled", true).apply();
        scheduleReminder(101, 10, 0, "Hora da água 💧", "Duda, que tal beber um copo de água agora?");
        scheduleReminder(102, 8, 30, "Um carinho no seu dia 💗", "Abra o Meu Dia e cuide um pouquinho de você hoje.");
        scheduleReminder(103, 11, 30, "Receita do dia 🍰", "Sua receita de hoje está esperando por você!");
        scheduleReminder(104, 19, 0, "A Mia está te esperando 🐱", "Passe no cantinho da Mia para brincar e cuidar dela.");
    }

    private void disableAllReminders() {
        reminderPrefs.edit().putBoolean("enabled", false).apply();
        AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        for(int id=101; id<=104; id++){
            PendingIntent pi=PendingIntent.getBroadcast(this,id,new Intent(this,NotificationReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null){am.cancel(pi);pi.cancel();}
        }
    }

    public class RemindersBridge {
        @JavascriptInterface public void enableAll() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
                }
                enableAllReminders();
                webView.evaluateJavascript("if(window.updateReminderStatus)updateReminderStatus(true);", null);
            });
        }
        @JavascriptInterface public void disableAll() { runOnUiThread(() -> { disableAllReminders(); webView.evaluateJavascript("if(window.updateReminderStatus)updateReminderStatus(false);", null); }); }
        @JavascriptInterface public boolean isEnabled() { return reminderPrefs.getBoolean("enabled", false); }
    }

    public class AdsBridge {
        @JavascriptInterface
        public void showInterstitial(String placement) {
            MainActivity.this.showInterstitial();
        }

        @JavascriptInterface
        public void showRewarded(String placement) {
            MainActivity.this.showRewarded();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
