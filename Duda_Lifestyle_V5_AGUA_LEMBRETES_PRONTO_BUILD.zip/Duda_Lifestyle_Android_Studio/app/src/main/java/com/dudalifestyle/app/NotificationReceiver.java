package com.dudalifestyle.app;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

public class NotificationReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent){
   int id=intent.getIntExtra("id",100); String title=intent.getStringExtra("title"); String text=intent.getStringExtra("text");
   Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
   PendingIntent content=PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   NotificationCompat.Builder b=new NotificationCompat.Builder(context,"duda_daily").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(content).setPriority(NotificationCompat.PRIORITY_DEFAULT);
   ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
 }
}
