DUDA LIFESTYLE - GERAR APK PELO CELULAR

Este projeto inclui um fluxo do GitHub Actions que gera o APK sem precisar instalar Android Studio no celular.

RESUMO:
1. Crie/entre em uma conta no GitHub pelo navegador do celular.
2. Crie um repositório novo e envie TODO o conteúdo desta pasta Duda_Lifestyle_Android_Studio para a raiz do repositório.
3. Abra a aba Actions do repositório.
4. Abra "Gerar APK Duda Lifestyle".
5. Toque em "Run workflow" e confirme.
6. Quando o processo terminar com sinal verde, abra a execução.
7. Em Artifacts, baixe "Duda-Lifestyle-APK".
8. O arquivo app-debug.apk estará dentro do ZIP baixado.

IMPORTANTE:
- O APK gerado por este fluxo é de TESTE (debug), ideal para instalar no seu celular e conferir o aplicativo.
- O projeto continua usando IDs oficiais de TESTE do Google AdMob; esses anúncios não geram dinheiro.
- Antes de publicar na Play Store, será necessário usar seus IDs reais do AdMob e gerar um AAB de release assinado.
- O projeto usa Android Gradle Plugin 9.3.0, que exige Gradle 9.5.0 ou superior, e Java 17.
