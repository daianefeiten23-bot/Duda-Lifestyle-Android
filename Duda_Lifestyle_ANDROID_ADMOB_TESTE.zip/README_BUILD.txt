DUDA LIFESTYLE — PROJETO ANDROID

Este projeto usa o HTML final em:
app/src/main/assets/index.html

MONETIZAÇÃO:
- Está configurado SOMENTE com IDs oficiais de TESTE do Google AdMob.
- Nunca publique esta build esperando receita: anúncios de teste não pagam.
- Antes da Play Store, substitua o App ID e o Rewarded Ad Unit ID pelos IDs reais da sua própria conta AdMob.
- Não clique nos próprios anúncios reais.

JÁ PREPARADO:
- WebView + LocalStorage
- Vídeos locais do HTML
- Permissão de microfone
- Permissão de notificações
- Google Mobile Ads SDK
- Rewarded Ad: recompensa somente após conclusão confirmada
- UMP incluído como dependência para etapa de consentimento

IMPORTANTE ANTES DE PUBLICAR:
- Integrar/validar a tela de consentimento UMP conforme os países atendidos.
- Revisar Data Safety/Política de Privacidade.
- Testar todos os fluxos de recompensa no APK.
