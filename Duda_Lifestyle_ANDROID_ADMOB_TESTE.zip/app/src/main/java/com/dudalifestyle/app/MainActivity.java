package com.dudalifestyle.app;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.webkit.*;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.rewarded.*;
import com.google.android.ump.*;

public class MainActivity extends Activity {
    WebView web;
    RewardedAd rewardedAd;
    final int REQ_MIC=20;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(com.dudalifestyle.app.R.layout.activity_main);
        web=findViewById(com.dudalifestyle.app.R.id.webview);

        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest r){
                if(android.os.Build.VERSION.SDK_INT>=23 &&
                   checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC);
                } else r.grant(r.getResources());
            }
        });

        // Bridge used by HTML for rewarded ads.
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void showRewardedAd(){
                runOnUiThread(()->showRewarded());
            }
        },"DudaAndroid");

        MobileAds.initialize(this, status -> loadRewarded());

        if(android.os.Build.VERSION.SDK_INT>=33 &&
           checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);
        }

        web.loadUrl("file:///android_asset/index.html");
    }

    void loadRewarded(){
        // Official Google rewarded TEST ad unit.
        AdRequest req=new AdRequest.Builder().build();
        RewardedAd.load(this,"ca-app-pub-3940256099942544/5224354917",req,
          new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(@NonNull RewardedAd ad){ rewardedAd=ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError e){ rewardedAd=null; }
          });
    }

    void showRewarded(){
        if(rewardedAd==null){ loadRewarded(); return; }
        rewardedAd.show(this, rewardItem -> {
            // Reward is granted ONLY after Google confirms completion.
            web.evaluateJavascript(
              "window.dispatchEvent(new CustomEvent('dudaRewardedAdCompleted'));",null);
        });
        rewardedAd=null;
        loadRewarded();
    }

    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
